﻿### Define Deployment Variables
{
$location = 'West Europe'
$resourceGroupName = 'TEST'
$resourceDeploymentName = 'ArmTemplate'
$templatePath = $env:SystemDrive + '\' + 'Users\nedaz\OneDrive\Documents\GitHub\pluralsight\microsoft-azure-resource-manager-mastering'
## define where template file is located
$templateFile = 'simpleIaas.json'
$template = $templatePath + '\' + $templateFile
}

### Create Resource Group
{
New-AzureRmResourceGroup `
    -Name $resourceGroupName `
    -Location $location `
    -Verbose -Force
}

### Deploy Resources
{
New-AzureRmResourceGroupDeployment `
    -Name $resourceDeploymentName `
    -ResourceGroupName $resourceGroupName `
    -TemplateFile $template `
    -Verbose -Force
}